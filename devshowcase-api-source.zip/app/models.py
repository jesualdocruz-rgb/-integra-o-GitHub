from datetime import datetime
from sqlalchemy import ForeignKey, String, Table, Column, Text, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

project_technology = Table(
    "project_technology", Base.metadata,
    Column("project_id", ForeignKey("projects.id", ondelete="CASCADE"), primary_key=True),
    Column("technology_id", ForeignKey("technologies.id", ondelete="CASCADE"), primary_key=True),
)

class Profile(Base):
    __tablename__ = "profiles"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    bio: Mapped[str | None] = mapped_column(Text)
    avatar_url: Mapped[str | None] = mapped_column(String(500))
    github_url: Mapped[str | None] = mapped_column(String(500))
    projects: Mapped[list["Project"]] = relationship(back_populates="profile", cascade="all, delete-orphan")

class Project(Base):
    __tablename__ = "projects"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(160), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    repository_url: Mapped[str] = mapped_column(String(500), nullable=False)
    demo_url: Mapped[str | None] = mapped_column(String(500))
    profile_id: Mapped[int] = mapped_column(ForeignKey("profiles.id"), nullable=False)
    profile: Mapped[Profile] = relationship(back_populates="projects")
    technologies: Mapped[list["Technology"]] = relationship(secondary=project_technology, back_populates="projects")
    feedback: Mapped[list["Feedback"]] = relationship(back_populates="project", cascade="all, delete-orphan")

class Technology(Base):
    __tablename__ = "technologies"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    projects: Mapped[list[Project]] = relationship(secondary=project_technology, back_populates="technologies")

class Feedback(Base):
    __tablename__ = "feedback"
    id: Mapped[int] = mapped_column(primary_key=True)
    author_name: Mapped[str] = mapped_column(String(120), nullable=False)
    comment: Mapped[str] = mapped_column(Text, nullable=False)
    rating: Mapped[int | None]
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), nullable=False)
    project: Mapped[Project] = relationship(back_populates="feedback")
