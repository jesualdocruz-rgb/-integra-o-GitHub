from fastapi import Depends, FastAPI, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session
from .database import Base, engine, get_db
from .models import Profile, Project, Technology
from .schemas import ProfileCreate, ProfileOut, ProjectCreate, ProjectOut, TechnologyCreate, TechnologyOut

Base.metadata.create_all(bind=engine)
app = FastAPI(title="DevShowcase API", version="1.0.0", description="API para apresentação de perfis e projetos de desenvolvedores.")

def normalize(value: str) -> str:
    return " ".join(value.strip().split())

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/profiles", response_model=ProfileOut, status_code=status.HTTP_201_CREATED)
def create_profile(payload: ProfileCreate, db: Session = Depends(get_db)):
    profile = Profile(name=normalize(payload.name), bio=payload.bio, avatar_url=str(payload.avatar_url) if payload.avatar_url else None, github_url=str(payload.github_url) if payload.github_url else None)
    db.add(profile); db.commit(); db.refresh(profile)
    return profile

@app.get("/api/profiles/{profile_id}", response_model=ProfileOut)
def get_profile(profile_id: int, db: Session = Depends(get_db)):
    profile = db.get(Profile, profile_id)
    if not profile: raise HTTPException(status_code=404, detail="Perfil não encontrado")
    return profile

@app.post("/api/technologies", response_model=TechnologyOut, status_code=status.HTTP_201_CREATED)
def create_technology(payload: TechnologyCreate, db: Session = Depends(get_db)):
    name = normalize(payload.name)
    existing = db.scalar(select(Technology).where(Technology.name.ilike(name)))
    if existing: raise HTTPException(status_code=409, detail="Tecnologia já cadastrada")
    technology = Technology(name=name); db.add(technology); db.commit(); db.refresh(technology)
    return technology

@app.get("/api/technologies", response_model=list[TechnologyOut])
def list_technologies(db: Session = Depends(get_db)):
    return list(db.scalars(select(Technology).order_by(Technology.name)).all())

@app.post("/api/projects", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectCreate, db: Session = Depends(get_db)):
    if not db.get(Profile, payload.profile_id): raise HTTPException(status_code=404, detail="Perfil não encontrado")
    technologies = list(db.scalars(select(Technology).where(Technology.id.in_(payload.technology_ids))).all()) if payload.technology_ids else []
    if len(technologies) != len(set(payload.technology_ids)): raise HTTPException(status_code=400, detail="Uma ou mais tecnologias não foram encontradas")
    project = Project(title=normalize(payload.title), description=payload.description.strip(), repository_url=str(payload.repository_url), demo_url=str(payload.demo_url) if payload.demo_url else None, profile_id=payload.profile_id, technologies=technologies)
    db.add(project); db.commit(); db.refresh(project)
    return project

@app.get("/api/projects", response_model=list[ProjectOut])
def list_projects(db: Session = Depends(get_db)):
    return list(db.scalars(select(Project).order_by(Project.id.desc())).all())
