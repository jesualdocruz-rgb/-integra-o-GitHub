from pydantic import AnyHttpUrl, BaseModel, ConfigDict, Field

class ProfileCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    bio: str | None = Field(default=None, max_length=2000)
    avatar_url: AnyHttpUrl | None = None
    github_url: AnyHttpUrl | None = None

class ProfileOut(ProfileCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int

class TechnologyCreate(BaseModel):
    name: str = Field(min_length=2, max_length=80)

class TechnologyOut(TechnologyCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int

class ProjectCreate(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    description: str = Field(min_length=10, max_length=5000)
    repository_url: AnyHttpUrl
    demo_url: AnyHttpUrl | None = None
    profile_id: int = Field(gt=0)
    technology_ids: list[int] = Field(default_factory=list)

class ProjectOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    description: str
    repository_url: str
    demo_url: str | None
    profile_id: int
    technologies: list[TechnologyOut]
