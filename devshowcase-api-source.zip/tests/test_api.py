from .conftest import client

def test_profile_and_not_found():
    response = client.post("/api/profiles", json={"name":"Ada Lovelace","bio":"Backend developer","github_url":"https://github.com/ada"})
    assert response.status_code == 201
    profile_id = response.json()["id"]
    assert client.get(f"/api/profiles/{profile_id}").status_code == 200
    assert client.get("/api/profiles/9999").status_code == 404

def test_validation_and_technology():
    assert client.post("/api/technologies", json={"name":""}).status_code == 422
    assert client.post("/api/technologies", json={"name":"FastAPI"}).status_code == 201
    assert client.post("/api/technologies", json={"name":"FastAPI"}).status_code == 409
    assert len(client.get("/api/technologies").json()) >= 1

def test_project_relationships():
    profile = client.post("/api/profiles", json={"name":"Grace Hopper"}).json()
    tech = client.post("/api/technologies", json={"name":"Python"}).json()
    project = client.post("/api/projects", json={"title":"API portfolio","description":"A portfolio API with relational persistence.","repository_url":"https://github.com/example/api","profile_id":profile["id"],"technology_ids":[tech["id"]]})
    assert project.status_code == 201
    assert project.json()["technologies"][0]["name"] == "Python"
    assert client.get("/api/projects").status_code == 200
